#include <iostream>
using namespace std;

int main() {
    int a; char b; bool c; float d; double e;
    cin >> a >> b >> c >> d >> e;
    cout << a << endl << b << endl << c << endl << d << endl << e;
    return 0;
}
