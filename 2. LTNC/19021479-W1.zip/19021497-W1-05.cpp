int max4(int a, b, c, d) {
    int m = a;
    if (b > m) m=b;
    if (c > m) m=c;
    if (d > m) m=d;
    return m;
}
